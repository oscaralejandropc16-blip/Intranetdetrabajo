<?php
/**
 * Plugin Name: RD Intranet Backend
 * Plugin URI: https://romanydelgado.com
 * Description: Backend personalizado para la Intranet de Román & Delgado. Gestiona la base de datos de bitácoras, API REST segura y automatización de correos a las 6PM.
 * Version: 1.0.0
 * Author: Tu Agente Antigravity
 * Text Domain: rd-intranet
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

// 1. Registrar Custom Post Type: Bitácora Diaria
function rd_intranet_register_cpt() {
    $args = array(
        'public'       => false, // No visible en frontend público
        'show_ui'      => true,  // Visible en el wp-admin (opcional, para emergencias)
        'label'        => 'Bitácoras Intranet',
        'supports'     => array('title', 'editor', 'author', 'custom-fields'),
        'show_in_rest' => true,
    );
    register_post_type('rd_bitacora', $args);
}
add_action('init', 'rd_intranet_register_cpt');

// 2. Registrar Endpoints de la API REST
add_action('rest_api_init', function () {
    
    // Endpoint: POST /rd-intranet/v1/submit (Guardar Bitácora)
    register_rest_route('rd-intranet/v1', '/submit', array(
        'methods' => 'POST',
        'callback' => 'rd_intranet_handle_submit',
        'permission_callback' => function () {
            // Requiere usuario logueado (verificado vía JWT plugin)
            return is_user_logged_in();
        }
    ));

    // Endpoint: GET /rd-intranet/v1/bitacoras (Obtener para el Dashboard del Admin)
    register_rest_route('rd-intranet/v1', '/bitacoras', array(
        'methods' => 'GET',
        'callback' => 'rd_intranet_get_bitacoras',
        'permission_callback' => function () {
            // Solo los jefes pueden ver esto
            return current_user_can('administrator'); 
        }
    ));
    
    // Endpoint: POST /rd-intranet/v1/admin-update (Modificar y Comentar por el Jefe)
    register_rest_route('rd-intranet/v1', '/admin-update', array(
        'methods' => 'POST',
        'callback' => 'rd_intranet_handle_admin_update',
        'permission_callback' => function () {
            return current_user_can('administrator'); 
        }
    ));
});

function rd_intranet_handle_submit($request) {
    $user_id = get_current_user_id();
    $params = $request->get_json_params();
    
    $reporte_hoy = sanitize_textarea_field($params['reporte_hoy'] ?? '');
    $programacion_manana = sanitize_text_field($params['programacion_manana'] ?? '');
    $hora_entrada = sanitize_text_field($params['hora_entrada'] ?? '');
    $hora_salida = current_time('mysql'); // Toma la hora del servidor al momento del cierre

    $post_data = array(
        'post_title'    => 'Bitácora - ' . get_userdata($user_id)->display_name . ' - ' . date('Y-m-d'),
        'post_content'  => "REPORTE HOY:\n$reporte_hoy\n\nPROGRAMACIÓN FUTURA:\n$programacion_manana",
        'post_status'   => 'publish',
        'post_author'   => $user_id,
        'post_type'     => 'rd_bitacora'
    );

    $post_id = wp_insert_post($post_data);
    
    if (is_wp_error($post_id)) {
        return new WP_Error('db_error', 'No se pudo guardar la bitácora', array('status' => 500));
    }

    // Guardar Metadata (Custom Fields)
    update_post_meta($post_id, 'hora_entrada', $hora_entrada);
    update_post_meta($post_id, 'hora_salida', $hora_salida);
    update_post_meta($post_id, 'estado_revision', 'Enviado'); // Para que el admin sepa que es nuevo

    return rest_ensure_response(array('success' => true, 'message' => 'Día cerrado exitosamente.', 'post_id' => $post_id));
}

function rd_intranet_get_bitacoras() {
    $args = array(
        'post_type' => 'rd_bitacora',
        'posts_per_page' => 50, // Últimas 50
        'post_status' => 'publish'
    );
    
    $query = new WP_Query($args);
    $resultados = array();
    
    if ($query->have_posts()) {
        while ($query->have_posts()) {
            $query->the_post();
            $resultados[] = array(
                'id' => get_the_ID(),
                'user' => get_the_author(),
                'date' => get_the_date('Y-m-d'),
                'clockIn' => get_post_meta(get_the_ID(), 'hora_entrada', true),
                'clockOut' => get_post_meta(get_the_ID(), 'hora_salida', true),
                'status' => get_post_meta(get_the_ID(), 'estado_revision', true) ?: 'Enviado',
                'content' => get_the_content()
            );
        }
        wp_reset_postdata();
    }
    
    return rest_ensure_response($resultados);
}

function rd_intranet_handle_admin_update($request) {
    $params = $request->get_json_params();
    $post_id = intval($params['post_id'] ?? 0);
    $nuevo_comentario = sanitize_textarea_field($params['comentario_admin'] ?? '');
    
    if ($post_id > 0) {
        update_post_meta($post_id, 'comentario_admin', $nuevo_comentario);
        update_post_meta($post_id, 'estado_revision', 'Revisado');
        
        // Aquí se dispararía una notificación al empleado de que su jefe le dejó un comentario
        return rest_ensure_response(array('success' => true, 'message' => 'Bitácora actualizada y empleado notificado.'));
    }
    return new WP_Error('invalid_id', 'ID inválido', array('status' => 400));
}

// 3. WP-Cron: Tarea Automática a las 6:00 PM (Envío de Resumen a Jefes)
if (!wp_next_scheduled('rd_intranet_6pm_cron_hook')) {
    // Configurar para las 18:00 hora local (Requiere ajustar el timezone en WP Settings)
    $time_6pm = strtotime('today 18:00:00'); 
    wp_schedule_event($time_6pm, 'daily', 'rd_intranet_6pm_cron_hook');
}

add_action('rd_intranet_6pm_cron_hook', 'rd_intranet_send_daily_summary_email');

function rd_intranet_send_daily_summary_email() {
    $jefes_emails = array('victorroman@romanydelgado.com', 'luisdelgado@romanydelgado.com'); // Mails simulados
    
    // Contar cuántas bitácoras se subieron hoy
    $args = array(
        'post_type' => 'rd_bitacora',
        'date_query' => array(
            array(
                'year'  => date('Y'),
                'month' => date('m'),
                'day'   => date('d'),
            ),
        ),
    );
    $query = new WP_Query($args);
    $count = $query->found_posts;
    
    $subject = 'Resumen de Bitácoras Intranet - ' . date('d/m/Y');
    $message = "Hola equipo,\n\nEste es un recordatorio automático.\n\nHoy se han cargado $count bitácoras nuevas.\nPor favor, ingresen al Panel Administrativo de la Intranet para revisarlas, modificarlas o dejar sugerencias a los empleados.\n\nSaludos,\nSistema Intranet Román & Delgado.";
    
    wp_mail($jefes_emails, $subject, $message);
}
